elements.hello_world = {
  color: "#189aa3",
  behavior: behaviors.SUPERFLUID,
  category: "land",
  state: "solid",
  hidden: false,
  reactions: {
      'wood': {elem1:null,elem2: 'static'}
  }
};