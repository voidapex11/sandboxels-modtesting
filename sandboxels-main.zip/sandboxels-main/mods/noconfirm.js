window.confirm = () => true;
